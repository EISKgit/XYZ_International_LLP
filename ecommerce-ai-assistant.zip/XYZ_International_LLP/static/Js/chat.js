document.addEventListener('DOMContentLoaded', function () {
    const chatToggle = document.getElementById('chat-toggle');
    const chatWidget = document.getElementById('chat-widget');

    if (chatToggle) {
        chatToggle.addEventListener('click', function () {
            chatWidget.style.display = 'flex';
            chatToggle.style.display = 'none';
        });
    }
});

function closeChat() {
    document.getElementById('chat-widget').style.display = 'none';
    document.getElementById('chat-toggle').style.display = 'flex';
}


async function sendMessage() {
    let input = document.getElementById('chat-input');
    let chatBody = document.getElementById('chat-body');
    let userMsg = input.value.trim();
    if (!userMsg) return;

    // Add user message
    chatBody.innerHTML += `<div><b>You:</b> ${userMsg}</div>`;
    input.value = "";

    // Create new AI placeholder each time
    let aiDiv = document.createElement('div');
    aiDiv.innerHTML = `<b>AI:</b> <span class="ai-stream"></span>`;
    chatBody.appendChild(aiDiv);

    try {
        let res = await fetch('/api/ai/', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ query: userMsg })
        });
        let data = await res.json();

        let aiText = data.answer;
        let aiSpan = aiDiv.querySelector(".ai-stream");
        let i = 0;

        function typeChar() {
            if (i < aiText.length) {
                aiSpan.textContent += aiText[i];
                i++;
                setTimeout(typeChar, 20);
            }
        }
        typeChar();

        chatBody.scrollTop = chatBody.scrollHeight;
    } catch (err) {
        aiDiv.innerHTML = `<b>AI:</b> <span style="color:red;">Error: ${err.message}</span>`;
    }
}
